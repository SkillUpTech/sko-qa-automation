package com.seo.regression.testing;

public class BusinessPageLocator {

}
